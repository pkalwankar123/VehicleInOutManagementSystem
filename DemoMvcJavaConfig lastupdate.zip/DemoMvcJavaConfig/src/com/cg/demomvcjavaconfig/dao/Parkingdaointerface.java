package com.cg.demomvcjavaconfig.dao;

import java.util.List;

import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.InvalidParkingId;

public interface Parkingdaointerface {
	public Parking save(Parking parking) throws InvalidOwnerId, InvalidParkingId;
	public List<Parking> findById(int id);
}
