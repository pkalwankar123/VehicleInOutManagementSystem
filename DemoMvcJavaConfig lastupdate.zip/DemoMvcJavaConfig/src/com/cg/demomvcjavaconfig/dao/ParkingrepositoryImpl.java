package com.cg.demomvcjavaconfig.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.InvalidParkingId;
@Repository
public class ParkingrepositoryImpl implements Parkingdaointerface{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public Parking save(Parking parking) throws InvalidOwnerId {
	
		
		int owner_id=parking.getOwner().getId();
		
		
/*int parking_id=parking.getId();*/
		
		
		
		
		Query queryOne  = entitymanager.createQuery("Select a From Owner a where owner_id= :owner_id");
		List<Owner> owner=queryOne.setParameter("owner_id", owner_id).getResultList();
		
		/*Query query  = entitymanager.createQuery("Select a From Parking a where parking_id= :parking_id");
		List<Parking> park=query.setParameter("parking_id", parking_id).getResultList();
*/		
		if(!(owner.isEmpty())) {
			entitymanager.persist(parking);
			entitymanager.flush();
		}
		else{
			throw new InvalidOwnerId("OOPS..Owner Not found into the Database."
					+ " Please enter the valid Owner number and try again!!");
		}
		 
			
		
		
		
		
		
		return parking;
		
		
		
		
	}
	
	
	public List<Parking> findById(int id)
	{
		
//List<Vehicle> depts;
Query query  = entitymanager.createQuery("Select a From Parking a where parking_id= :id");
 

 List<Parking> depts=query.setParameter("id", id).getResultList();
return depts;
}

}
