package com.cg.demomvcjavaconfig.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.demomvcjavaconfig.dto.Parkingslot;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;


public interface Parkingslotrepositoryinterface {
	public Parkingslot create(Parkingslot parkslot)throws InvalidOwnerId;
	public List<Parkingslot> findByid(int id) throws SQLException;

}

