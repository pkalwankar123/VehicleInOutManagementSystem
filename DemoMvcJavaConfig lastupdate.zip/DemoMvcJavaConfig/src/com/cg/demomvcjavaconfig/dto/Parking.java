package com.cg.demomvcjavaconfig.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
//Entity class created
@Entity
@Table(name="parking")
public class Parking {
	//Attributes//
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="parking_id")
	private int id;
	@Column(name="location")
	private String location;
	
	@OneToOne(cascade=CascadeType.MERGE)
    @JoinColumn(name="owner_id")
	private Owner owner;
	
	//Constructors//
	public Parking (){}

	public Parking(int id, String location, Owner owner) {
		super();
		this.id = id;
		this.location = location;
		this.owner = owner;
	}
	//Constructors//
	
	//Getter and setters//
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "parking [id=" + id + ", Location=" + location + "]";
	}
	
}
