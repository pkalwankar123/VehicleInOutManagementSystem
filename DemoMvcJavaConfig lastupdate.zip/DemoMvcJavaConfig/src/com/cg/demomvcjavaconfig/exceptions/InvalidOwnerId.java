package com.cg.demomvcjavaconfig.exceptions;

public class InvalidOwnerId extends Exception {
	public InvalidOwnerId() {}
	
	public InvalidOwnerId(String msg) {
		
		super(msg);
	}
	
}
