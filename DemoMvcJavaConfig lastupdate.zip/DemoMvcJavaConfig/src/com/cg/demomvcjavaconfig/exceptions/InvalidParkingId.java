package com.cg.demomvcjavaconfig.exceptions;

public class InvalidParkingId extends Exception {
	public InvalidParkingId() {}
	
	public InvalidParkingId(String msg) {
		
		super(msg);
	}
	
}
