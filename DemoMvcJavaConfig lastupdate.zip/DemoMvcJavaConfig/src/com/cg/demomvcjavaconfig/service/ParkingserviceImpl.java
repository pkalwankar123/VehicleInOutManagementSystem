package com.cg.demomvcjavaconfig.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.OwnerrepositoryImp;
import com.cg.demomvcjavaconfig.dao.ParkingrepositoryImpl;
import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.InvalidParkingId;
@Service
@Transactional
public class ParkingserviceImpl implements Parkingserviceinterface {
	@Autowired
	ParkingrepositoryImpl park;
	
	@Override
	public Parking add(Parking parking) throws InvalidOwnerId {
		
		return park.save(parking);
	}

	@Override
	public List<Parking> searchByid(int id) {
		// TODO Auto-generated method stub
		 return park.findById(id);
	}

	
	
	
	
}
