package com.cg.demomvcjavaconfig.service;

import java.util.List;

import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.dto.Parkingslot;
import com.cg.demomvcjavaconfig.dto.Vehicle;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.InvalidParkingId;
import com.cg.demomvcjavaconfig.exceptions.ParkingNotFoundException;

public interface Parkingserviceinterface {
	public Parking add(Parking parking) throws InvalidOwnerId;
	public List<Parking> searchByid(int id);
}
