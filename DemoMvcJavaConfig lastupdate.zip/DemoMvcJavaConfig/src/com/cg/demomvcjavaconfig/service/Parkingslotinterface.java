package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.cg.demomvcjavaconfig.dto.Parkingslot;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.ParkingNotFoundException;


public interface Parkingslotinterface {
	public Parkingslot createParkingslot(Parkingslot parkingslot) throws InvalidOwnerId ;
	public List<Parkingslot> searchByid(int id) throws ParkingNotFoundException;

}