package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.ParkingslotrepositoryImp;
import com.cg.demomvcjavaconfig.dto.Parkingslot;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.ParkingNotFoundException;
import com.cg.demomvcjavaconfig.exceptions.VehicleNotFoundException;
@Service
@Transactional
public class ParkingslotserviceImp implements Parkingslotinterface{

@Autowired
	ParkingslotrepositoryImp parkslot;
	
	
	
	
	public Parkingslot createParkingslot(Parkingslot parkingslot) throws InvalidOwnerId{
		return parkslot.create(parkingslot);
	}
	
	public List<Parkingslot> searchByid(int id) throws ParkingNotFoundException{
		// TODO Auto-generated method stub
		
		
		if(parkslot.findByid(id).isEmpty()){
			throw new ParkingNotFoundException("OOPS..Parkingslot Not found into the Database."
					+ " Please enter the valid slotID and try again!!");
		
		}else
		
			return parkslot.findByid(id);
	}

		
		
	

}

