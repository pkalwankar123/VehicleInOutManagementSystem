package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;

import com.cg.demomvcjavaconfig.dto.Parktransaction;


public interface Parkingtransserivceinterface {

	public void bookParking(Parktransaction parktrans);
	
}
