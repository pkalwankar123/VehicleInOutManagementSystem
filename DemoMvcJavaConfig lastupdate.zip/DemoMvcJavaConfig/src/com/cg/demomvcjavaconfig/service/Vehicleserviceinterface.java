package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.demomvcjavaconfig.dto.Vehicle;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.VehicleNotFoundException;



public interface Vehicleserviceinterface {


	public Vehicle add(Vehicle vehicle) throws InvalidOwnerId;
	public List<Vehicle> searchbyVehNo(String vehNo);

}
