package com.cg.demomvcjavaconfig.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.dto.Vehicle;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;
import com.cg.demomvcjavaconfig.exceptions.VehicleNotFoundException;
import com.cg.demomvcjavaconfig.service.Ownerserviceinterface;
import com.cg.demomvcjavaconfig.service.Parkingserviceinterface;
import com.cg.demomvcjavaconfig.service.Vehicleserviceinterface;



@Controller
public class MyController {

	@Autowired
	Ownerserviceinterface ownerService;
	@Autowired
	Vehicleserviceinterface vehicleService;
	@Autowired
	Parkingserviceinterface parkingService;
	
	@GetMapping("login")
	public String loginPage()
	{
		return "listpage";
	}
	
	
	 @GetMapping("addOwnerr")
	 public ModelAndView getAddCustomer(@ModelAttribute("owner") Owner owe) {
		 
		 Map<String, Object> myMap = new HashMap<>();
		 Set<String> listOfArea = new HashSet<String>();
		 //List<String> listOfArea=new ArrayList<>();
		 listOfArea.add("Talwade");
		 listOfArea.add("Nigdi");
		 listOfArea.add("Vadgaon");
		 listOfArea.add("Deccan");
		 listOfArea.add("Alandi");
		 listOfArea.add("Vashi");
		 listOfArea.add("Chembur");
		 listOfArea.add("Nerul");
		 listOfArea.add("Mankhurd");
		 
		 
		 
		 Set<String> listOfCity = new HashSet<String>();
		 listOfCity.add("Pune");
		 listOfCity.add("Mumbai");
		
		 
		 
		 myMap.put("listofarea", listOfArea);
		 myMap.put("listofcity", listOfCity);
		 
	
		 return new ModelAndView("addowner", "details", myMap);
	 }
	
	 @PostMapping("addOwner")
	 public ModelAndView addCustomer(@ModelAttribute("owner") Owner ower) {

		 Owner owner= ownerService.add(ower);
		 return new ModelAndView("success","key",owner);
	 }
	 
	
	 @GetMapping("success")
		public String homePage()
		{
			return "listpage";
		}
	 
 @GetMapping("addVehicle")
	 public ModelAndView getAddVehicle(@ModelAttribute("vehic") Vehicle vehic) {
				 
		 return new ModelAndView("addvehicle","key",vehic);
	 }
	
	 @PostMapping("addVehicle")
	 public ModelAndView addCustomer(@ModelAttribute("vehic") Vehicle vehic) {
	 
		 int a=vehic.getOwner().getId();
		 List<Owner> owner=ownerService.searchbyVehNo(a);
		 Owner owee=null;
		 for(Owner owe: owner)
		 {
			 owee=owe;
		 }
		 Vehicle vehicle=null;
		try {
			vehicle = vehicleService.add(vehic);
			vehicle.setOwner(owee);
		} catch (InvalidOwnerId e) {
			
			return new ModelAndView("error");
			
		}
		 return new ModelAndView("successVehicle","key",vehicle);
	 }
	
	 
	 
	 
	 
	 @GetMapping("searchVehicle")
		public ModelAndView SEAR() {
		
		return new ModelAndView("searchvehicle");
		}
	 
	 
	 
		
		@PostMapping("search")
		public ModelAndView searchProduct(@RequestParam("vehicleNumber") String vehNo, Model m)
		{
			List<Vehicle> vehicle;
			
			
				vehicle = vehicleService.searchbyVehNo(vehNo);
				
				
			m.addAttribute("comm", vehicle);
			return new ModelAndView("searchvehicle");
			
		}
	 
	 
		
		
		
		
		 @GetMapping("addParkingOne")
		 public ModelAndView getAddParking(@ModelAttribute("park") Parking parking) {
					 
			 return new ModelAndView("addparking","key",parking);
		 }
		
		 @PostMapping("addParking")
		 public ModelAndView addCustomer(@ModelAttribute("parking") Parking parking) {
		 
			 int a=parking.getOwner().getId();
			 List<Owner> owner=ownerService.searchbyVehNo(a);
			 Owner owee=null;
			 for(Owner owe: owner)
			 {
				 owee=owe;
			 }
			 Parking parki=null;
			try {
				parki = parkingService.addParking(parki);
				parki.setOwner(owee);
			} catch (InvalidOwnerId e) {
				
				return new ModelAndView("error");
				
			}
			 return new ModelAndView("successParking","key",parki);
		 }
		
		 	
		
		
		
		
		
		
		
		
		
		
		
	
}
