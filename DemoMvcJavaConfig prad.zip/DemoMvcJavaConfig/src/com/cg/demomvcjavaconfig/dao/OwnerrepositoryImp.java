package com.cg.demomvcjavaconfig.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Vehicle;



@Repository
public class OwnerrepositoryImp implements Ownerrepositoryinterface{
	@PersistenceContext
	EntityManager entitymanager;

	public Owner save(Owner owner){
		
		entitymanager.persist(owner);
		entitymanager.flush();
	return owner;
	}

	
	
	public List<Owner> findById(int id)
	{
		
//List<Vehicle> depts;
Query query  = entitymanager.createQuery("Select a From Owner a where owner_id= :id");
 

 List<Owner> depts=query.setParameter("id", id).getResultList();
// veh.setnumber(number);
// veh.setnumber(number);
// depts.Vehicle.class).getResultList()


return depts;
}
}
