package com.cg.demomvcjavaconfig.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.demomvcjavaconfig.dto.Owner;


public interface Ownerrepositoryinterface {

	public Owner save(Owner owner);
	public List<Owner> findById(int id);
	
}
