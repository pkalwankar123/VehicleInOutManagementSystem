package com.cg.demomvcjavaconfig.dao;

import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;


public interface Parkingdaointerface {

	public Parking save(Parking park) throws InvalidOwnerId;
	


	
}
