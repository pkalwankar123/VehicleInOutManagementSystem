package com.cg.demomvcjavaconfig.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;

@Repository
public class ParkingrepositoryImp implements Parkingdaointerface{
	@PersistenceContext
	EntityManager em;
	

	public Parking save(Parking parking) throws InvalidOwnerId {

int owner_id=parking.getOwner().getId();

		Query queryOne  = em.createQuery("Select a From Owner a where owner_id= :owner_id");
		List<Owner> owner=queryOne.setParameter("owner_id", owner_id).getResultList();
		
	
		
		if(!(owner.isEmpty())) {
			
			em.persist(parking);

			em.flush();
			
		}
		else{
			throw new InvalidOwnerId("OOPS..Owner Not found into the Database."
					+ " Please enter the valid Owner number and try again!!");
		}
		
	return parking;	
		
	}
	
}


