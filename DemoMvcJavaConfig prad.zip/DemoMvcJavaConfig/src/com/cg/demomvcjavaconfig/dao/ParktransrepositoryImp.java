package com.cg.parkingmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import javax.persistence.EntityManager;

import com.cg.parkingmanagementsystem.dbutil.Dbutil;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.dto.Parktransaction;
import com.cg.parkingmanagementsystem.dto.Vehicle;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.invaliddetailexcepion;

public class ParktransrepositoryImp implements Parkingttransrepositoryinterface{

	EntityManager em;
	public ParktransrepositoryImp() {
		em=Dbutil.em;
	}

	public Parktransaction book(Parktransaction parktrans1) throws invaliddetailexcepion, InvaliddetailId, SQLException{

				
				em.getTransaction().begin();
			em.persist(parktrans1);

			em.getTransaction().commit();
			//em.close();
			return parktrans1;
		
	
	/*	
		
			
			con=DButil.getConnection();
			//DButil.parkingslot.add(parkslot);
			String query_insert="Insert into parkingtransaction(id,startdate,enddate,starttime,endtime,pkid,vehid) values(?,?,?,?,?,?,?)";
			String query="Select id from parkingtransaction where id=?";
			String queryOne="Select id,startdate,enddate,starttime,endtime from parkingslot where id=?";
			String queryTwo="Select startdate,enddate,starttime,endtime from parkingtransaction where id=?";
			PreparedStatement pstmone=null;
			PreparedStatement pstm=null;
			PreparedStatement pstmOne=null;
			PreparedStatement pstmTwo=null;
			try {
		
				
				
				pstm=con.prepareStatement(query);
				pstm.setInt(1, parktrans1.getId());
				ResultSet rs1=pstm.executeQuery();
				
				pstmOne=con.prepareStatement(queryOne);
				pstmOne.setInt(1, parktrans1.getPk().getId());
				ResultSet rs=pstmOne.executeQuery();
			
				pstmTwo=con.prepareStatement(queryTwo);
				pstmTwo.setInt(1, parktrans1.getId());
				ResultSet rs2=pstmTwo.executeQuery();
			
				
				List<Parkingslot> pko=new ArrayList<Parkingslot>();
				
				while(rs.next()){
					Parkingslot pl=new Parkingslot();
					int idi=rs.getInt(1);
					LocalDate st=(rs.getDate(2)).toLocalDate();
				pl.setStartDate(st);
				
				LocalDate ed=(rs.getDate(3)).toLocalDate();
				pl.setEndDate(ed);
				
				LocalTime stt=(rs.getTime(4)).toLocalTime();
				pl.setEndTime(stt);
				
				LocalTime edt=(rs.getTime(5)).toLocalTime();
				pl.setEndTime(edt);
				
				Parking pkkk=new Parking();
				pkkk.setId(1);
				
				Parkingslot p2=new Parkingslot(idi,pkkk,st,ed,stt,edt);
				
				pko.add(pl);
			}
			
				
				
				for(Parkingslot parkk: pko) {
					if (((parktrans1.getStartTime()).isBefore(parkk.getStartTime())) || ((parktrans1.getStartTime()).isAfter(parkk.getEndTime())) )  {
						
						
						
						throw new invaliddetailexcepion("OOPS..Slot is not available, Please enter the timings between "+(parkk.getStartTime())+" to "+(parkk.getEndTime()));
						}
					
					}
				
				
				List<Parktransaction> pkto=new ArrayList<Parktransaction>();
				Parktransaction plq=new Parktransaction();
				while(rs.next()){
					LocalDate st=(rs2.getDate(1)).toLocalDate();
				plq.setStartDate(st);
				
				LocalDate ed=(rs2.getDate(2)).toLocalDate();
				plq.setEndDate(ed);
				
				LocalTime stt=(rs2.getTime(3)).toLocalTime();
				plq.setEndTime(stt);
				
				LocalTime edt=(rs2.getTime(4)).toLocalTime();
				plq.setEndTime(edt);
				
				pkto.add(plq);
			}
			
				
					for(Parktransaction owe1:pkto){
						
						
						if ((((parktrans1.getStartTime()).isAfter(owe1.getStartTime())) && ((parktrans1.getStartTime()).isBefore(owe1.getEndTime())) ) || ((owe1.getStartTime().equals(parktrans1.getStartTime())) || (owe1.getEndTime().equals(parktrans1.getEndTime())))) {
						
							
							
								throw new invaliddetailexcepion("OOPS..Slot is alreaddy booked between "+owe1.getStartTime()+" to "+owe1.getEndTime());
								}
						
					}

				
				
				
			if(rs1.next()==false) {	
			//if(rs.next()==false){
				pstmone=con.prepareStatement(query_insert);
				pstmone.setInt(1, parktrans1.getId());
				
				java.sql.Date sd=java.sql.Date.valueOf(parktrans1.getStartDate());
				pstmone.setDate(2,sd);
				java.sql.Date ed=java.sql.Date.valueOf(parktrans1.getStartDate());
				pstmone.setDate(3,ed);
				
				Time st=Time.valueOf(parktrans1.getStartTime());
				pstmone.setTime(4, st);
				
				Time et=Time.valueOf(parktrans1.getEndTime());
				pstmone.setTime(5, et);
			
				pstmone.setInt(6, parktrans1.getPk().getId());
				pstmone.setInt(7, parktrans1.getVeh().getVehId());
				pstmone.executeUpdate();
				
				//if(rs.next()==true){	
					//if(vehicle.getVehId()!=rs.getInt(1) ){
						
							
					//}
				
				//}else {
					//throw new InvaliddetailId("OOPs, this ParkingSlotID already used. Kindly enter the another Parkingslot id!!");
					
			//	}
			
			
			
			}
			
				
				else {
					throw new InvaliddetailId("OOPs, You have entered the wrong ParkingTransID. Kindly enter the correct Parking id!!");
				}
			
			}
		catch(SQLException e) {
			e.printStackTrace();
				
			}
		

			
			
			
			*/
			
		
	
			
			//return parktrans1;
		}

	}

		
	
