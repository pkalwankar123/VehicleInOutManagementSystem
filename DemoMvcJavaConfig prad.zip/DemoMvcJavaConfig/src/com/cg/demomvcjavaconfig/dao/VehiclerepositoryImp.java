package com.cg.demomvcjavaconfig.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Vehicle;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;



@Repository
public class VehiclerepositoryImp implements Vehiclerepositoryinterface{
	@PersistenceContext
	EntityManager em;

	
	
	public Vehicle save(Vehicle vehicle) throws InvalidOwnerId {
		
		
		int owner_id=vehicle.getOwner().getId();
		
		
		
		
		Query queryOne  = em.createQuery("Select a From Owner a where owner_id= :owner_id");
		List<Owner> owner=queryOne.setParameter("owner_id", owner_id).getResultList();
		
		if(!(owner.isEmpty())) {
			
			em.persist(vehicle);
			em.flush();
			
			
		}
		
		else{
			throw new InvalidOwnerId("OOPS..Owner Not found into the Database."
					+ " Please enter the valid Owner number and try again!!");
		}
		 
		
		return vehicle;
	}

	public List<Vehicle> findByVehNo(String vehNumber)
			{
	
		Query query  = em.createQuery("Select a From Vehicle a where vehicle_number= :vehNumber");
		 
		
		 List<Vehicle> depts=query.setParameter("vehNumber", vehNumber).getResultList();
		
		return depts;
	}

	
}
