package com.cg.demomvcjavaconfig.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.demomvcjavaconfig.dto.Vehicle;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;


public interface Vehiclerepositoryinterface {
	public Vehicle save(Vehicle vehicle) throws InvalidOwnerId;
	public List<Vehicle> findByVehNo(String vehNo);


}
