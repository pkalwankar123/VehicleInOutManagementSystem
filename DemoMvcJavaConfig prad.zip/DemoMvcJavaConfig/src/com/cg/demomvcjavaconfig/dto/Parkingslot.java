package com.cg.demomvcjavaconfig.dto;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

//Entity class created
@Entity
@Table(name="Parkingslot")
public class Parkingslot {
	//Attributes//
	@Id
	@Column(name="parkingslot_id")
	private int id;
	
	@OneToOne(cascade=CascadeType.MERGE)
    @JoinColumn(name="parking_id")
	private Parking parking;
	
	//@Temporal(TemporalType.DATE)
	@Column(name="startdate")
	private Date startDate;
	//@Temporal(TemporalType.DATE)
	@Column(name="enddate")
	private Date endDate;
	//@Temporal(TemporalType.TIME)
	@Column(name="starttime")
	private Time startTime;
	//@Temporal(TemporalType.TIME)
	@Column(name="endtime")
	private Time endTime;

	//Constructors//
	public Parkingslot(){}
	public Parkingslot(int id, Parking parking, Date startDate, Date endDate,Time startTime, Time endTime) {
		super();
		this.id = id;
		this.parking = parking;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	//Getter and setters//
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Parking getParking() {
		return parking;
	}
	public void setParking(Parking parking) {
		this.parking = parking;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public Time getStartTime() {
		return startTime;
	}
	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}
	public Time getEndTime() {
		return endTime;
	}
	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "Parkingslot [id=" + id + ", parking=" + parking + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
		
	
	
	
}
