package com.cg.demomvcjavaconfig.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;



//Entity class created

@Entity
@Table(name="vehicle")
public class Vehicle {
	//Attributes//
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="vehicle_id")
	private int id;
	@Column(name="vehicle_number")
	private String number;
	@Column(name="vehicle_description")
	private String description;
	
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="owner_id")
	private Owner owner;
	
	
	

	//Constructors//
	public  Vehicle() {}

	public Vehicle(int id, String number, String description, Owner owner) {
		super();
		this.id = id;
		this.number = number;
		this.description = description;
		this.owner = owner;
	}

	//Getter and setters//
	public int getid() {
		return id;
	}


	public void setid(int id) {
		this.id = id;
	}


	public String getnumber() {
		return number;
	}


	public void setnumber(String number) {
		this.number = number;
	}


	public String getdescription() {
		return description;
	}


	public void setdescription(String description) {
		this.description = description;
	}


	public Owner getOwner() {
		return owner;
	}


	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	public String vehicleDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("Vehicle Id:- "+this.id);
		sb.append(" ");
		sb.append("Vehicle Number:-"+this.number);
		sb.append(" ");
		sb.append("Vehicle Description:-"+this.description);
		sb.append(" ");
		sb.append("Owner detail:-"+this.getOwner().ownerDetails());
		return sb.toString();	
	}
	

	

}