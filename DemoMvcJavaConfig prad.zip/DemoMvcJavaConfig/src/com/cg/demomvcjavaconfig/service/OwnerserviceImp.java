package com.cg.demomvcjavaconfig.service;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.OwnerrepositoryImp;
import com.cg.demomvcjavaconfig.dto.Owner;
import com.cg.demomvcjavaconfig.dto.Vehicle;


@Service
@Transactional
public class OwnerserviceImp implements Ownerserviceinterface{
	
	@Autowired
	OwnerrepositoryImp owner;
	
	public Owner add(Owner owe) {
		

		return owner.save(owe);
	}
	
public List<Owner> searchbyVehNo(int id){
		
		
		
		/*
		if(vehdao.findByVehNo(vehNo).isEmpty()){
			LOGGER.info("Inside function searchByVehno");
			LOGGER.warning("YOU HAVE ENTERED THE WRONG DATA!!!!");
			throw new VehicleNotFoundException("OOPS..Vehicle Not found into the Database."
					+ " Please enter the valid vehicle number and try again!!");
			
		}else {
		
			
	}*/

		return owner.findById(id);
}
}
