package com.cg.demomvcjavaconfig.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.ParkingrepositoryImp;
import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;

@Service
@Transactional
public class ParkingserviceImp implements Parkingserviceinterface{

	@Autowired
	ParkingrepositoryImp parkdao;
	
	
	public Parking addParking(Parking parking) throws InvalidOwnerId {

		return parkdao.save(parking);
	}


}

