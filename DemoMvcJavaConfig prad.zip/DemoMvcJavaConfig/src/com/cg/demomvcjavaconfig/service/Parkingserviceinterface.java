package com.cg.demomvcjavaconfig.service;

import com.cg.demomvcjavaconfig.dto.Parking;
import com.cg.demomvcjavaconfig.exceptions.InvalidOwnerId;


public interface Parkingserviceinterface {

	public Parking addParking(Parking parking) throws  InvalidOwnerId;
	
}
