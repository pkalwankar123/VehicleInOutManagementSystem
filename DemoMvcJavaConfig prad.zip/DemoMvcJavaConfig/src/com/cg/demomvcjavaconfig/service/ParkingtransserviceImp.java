package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;
import java.util.logging.Logger;

import com.cg.parkingmanagementsystem.dao.ParktransrepositoryImp;
import com.cg.parkingmanagementsystem.dto.Parktransaction;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.invaliddetailexcepion;

public class ParkingtransserviceImp implements Parkingtransserivceinterface{
ParktransrepositoryImp parktrans;
private final static Logger LOGGER =  
Logger.getLogger(Logger.GLOBAL_LOGGER_NAME); 
	public ParkingtransserviceImp(){
		parktrans=new ParktransrepositoryImp();
	}
	
	public void bookParking(Parktransaction parktrans1) throws invaliddetailexcepion, InvaliddetailId, SQLException{
		
		
		parktrans.book(parktrans1);
	}


}
