package com.cg.Parkingmanagementsys.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Parking;
import com.cg.Parkingmanagementsys.dto.Parkingslot;
import com.cg.Parkingmanagementsys.dto.Parktransaction;
import com.cg.Parkingmanagementsys.dto.Vehicle;
import com.cg.Parkingmanagementsys.exceptions.Invaliddate;
import com.cg.Parkingmanagementsys.exceptions.Invalidownerdetailexception;
import com.cg.Parkingmanagementsys.exceptions.Invalidowneridexception;
import com.cg.Parkingmanagementsys.exceptions.Invalidtime;
import com.cg.Parkingmanagementsys.exceptions.Invalidvehiclenumexception;
import com.cg.Parkingmanagementsys.exceptions.Invaliparkingidexception;
import com.cg.Parkingmanagementsys.exceptions.Invaliparkingslotidexception;
import com.cg.Parkingmanagementsys.service.Ownerservice;
import com.cg.Parkingmanagementsys.service.Parkingservice;
import com.cg.Parkingmanagementsys.service.Parkingslotservice;
import com.cg.Parkingmanagementsys.service.Parkingtransactionservice;
import com.cg.Parkingmanagementsys.service.Vehicleservice;




/*
 * RestController: It is the controller which tells us that this is the Restful web service and it controls all the request 
 * return: it returns the response according to the requested uri
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */



/*
 * @RestController: it tells the despathcer servlet that this is the Restcontroller
 * @RequestMapping: it contains the '/' and name that is nothing but the uri to reach to the all Restcontroller's methods
 * return: it returns the response according to the requested uri
 *@since: 2019-05-23
 */

@RestController
@RequestMapping("/parkingmgtsys")
public class Parkingcontroller {

	/*
	 * @Autowired: it is used to inject the class to get the properties
	 * services: we have included the list of Autowire classes 
	 * return: it returns the service class of corresponding object
	 *@since: 2019-05-23
	 */	
	
	
	/*
	 * @Autowired: it is used to inject the owner service class to get its properties
	 * return: it returns the owner service class of corresponding object
	 *@since: 2019-05-23
	 */	
	@Autowired
		Ownerservice ownerService;
		
	
	/*
	 * @Autowired: it is used to inject the vehicle service class to get its properties
	 * return: it returns the vehicle service class of corresponding object
	 *@since: 2019-05-23
	 */	
		@Autowired
		Vehicleservice vehicleService;

		
		/*
		 * @Autowired: it is used to inject the Parking service class to get its properties
		 * return: it returns the parking service class of corresponding object
		 *@since: 2019-05-23
		 */	
		@Autowired
		Parkingservice parkingService;
		
		
		/*
		 * @Autowired: it is used to inject the Parkingslot service class to get its properties
		 * return: it returns the Parkingslot service class of corresponding object
		 *@since: 2019-05-23
		 */	
		@Autowired
		Parkingslotservice parkingslotService;
		
		/*
		 * @Autowired: it is used to inject the Parkingtrans service class to get its properties
		 * return: it returns the Parkingtransaction service class of corresponding object
		 *@since: 2019-05-23
		 */	
		@Autowired
		Parkingtransactionservice parktransService;
		
		
		
		
		
		
		
		
		/*
		 * AddOwner mthod
		 * addowner: it is the uri though which we can reach to this method
		 * return: it returns the response of corresponding object
		 *@since: 2019-05-23
		 */	
		@RequestMapping(value="/addowner",method=RequestMethod.POST)
		@CrossOrigin(origins="http://localhost:4200")
		public ResponseEntity<Owner> addOwner(@ModelAttribute Owner owe) throws Invalidownerdetailexception {
			Owner owner=null;
			
			
			List<Owner> oer;
			
				
				/*
				 * ownerservice method
				 * Searchbyid: this method is to find the owner object
				 * return: it returns the service object for checking the duplicate owner
				 *@since: 2019-05-23
				 */	
				oer = ownerService.Searchbyid(owe.getId());
				
				/*
				 * ownerservice method
				 * add mthod: once the object is ready and we are passing it into the parameterlist of add method for adding owner
				 * owner: we are saving the added data to owner 
				 *@since: 2019-05-23
				 */	
				owner=ownerService.add(owe);
			
			

			/*
			  
			 * @Invalidownerdetailexception: throwing the error for invalid data
			 *@since: 2019-05-23
			 */	
			
			
			if(oer.isEmpty()) {
				
				if(owner==null){
					return new ResponseEntity("Owner data has not been addedd!!!",HttpStatus.NOT_FOUND);
					
				}
				
			}
			 /*
			 * @ResponseEntity: its giving response to corresponding to the Owner object
			 *@since: 2019-05-23
			 */	
			return new ResponseEntity<Owner>(owner,HttpStatus.OK);
		}
		

		/*
		 * AddVehicle method
		 * addvehicle: it is the uri though which we can reach to this method
		 * return: it returns the reponse of corresponding object
		 *@since: 2019-05-23
		 */	
		
		
		@RequestMapping(value="/addvehicle",method=RequestMethod.POST)
		@CrossOrigin(origins="http://localhost:4200")
		public ResponseEntity<Vehicle> addVehicle(@ModelAttribute Vehicle vehe) throws Invalidowneridexception {
			
Owner owner=null;
Vehicle vehicle=null;
			
			List<Owner> oer;
			
				/*
				 * vehicleservice method
				 * Searchbyid: this method is to find the owner object
				 * return: it returns the service object for checking the owner is valid
				 *@since: 2019-05-23
				 */	
				oer = ownerService.searchbyid(vehe.getOwner().getId());
				for(Owner owee:oer)
				{
					/*
					 * setting the owner to vehicle 
					 *@since: 2019-05-23
					 */
				vehe.setOwner(owee);
				}
				/*
				 * vehicleservice method
				 * add method: once the object is ready and we are passing it into the parameterlist of add method for adding vehicle
				 * vehicle: we are saving the added data to vehicle 
				 *@since: 2019-05-23
				 */	
				vehicle=vehicleService.add(vehe);
			
			/*
			  
			 * @Invalidownerdetailexception: throwing the error for invalid data
			 *@since: 2019-05-23
			 */	
			
			

		
		
			if(vehicle==null){
				return new ResponseEntity("Vehicle data has not been addedd!!!",HttpStatus.NOT_FOUND);
				
			}
			
			 /*
			 * @ResponseEntity: its giving response to corresponding to the Vehicle object
			 *@since: 2019-05-23
			 */	
		
			return new ResponseEntity<Vehicle>(vehicle,HttpStatus.OK);
		}
		

	
	
		
		
		@RequestMapping(value="/searchvehicle",method=RequestMethod.POST)
		@CrossOrigin(origins="http://localhost:4200")
		public ResponseEntity<List<Vehicle>> searchVehicle(@ModelAttribute Vehicle vehe) throws Invalidvehiclenumexception {
			
Owner owner=null;
List<Vehicle> vehicle=null;
			
				
					vehicle=vehicleService.findBynumber(vehe.getnumber());

		
			return new ResponseEntity<List<Vehicle>>(vehicle,HttpStatus.OK);
			
		}
	
		
		
		/*
		 * AddParking method
		 * addparking: it is the uri though which we can reach to this method
		 * return: it returns the reponse of corresponding object
		 *@since: 2019-05-23
		 */	
			
		@RequestMapping(value="/addparking",method=RequestMethod.POST)
		@CrossOrigin(origins="http://localhost:4200")
		public ResponseEntity<Parking> addParking(@ModelAttribute Parking park) throws Invalidowneridexception {
					
Owner owner=null;
Parking parking=null;
			


/*
 * Parkingservice method
 * searchbyid: this method is to find the owner object
 * return: it returns the service object for checking the owner is valid
 *@since: 2019-05-23
 */	
			List<Owner> oer;
			
				oer = ownerService.searchbyid(park.getOwner().getId());
				
				/*
				 * setting the owner to Parking 
				 *@since: 2019-05-23
				 */
				for(Owner owee:oer)
				{
					park.setOwner(owee);
				}
				
				/*
				 * Parkingservice method
				 * add method: once the object is ready and we are passing it into the parameterlist of add method for adding Parking
				 * Parking: we are saving the added data to Parking 
				 *@since: 2019-05-23
				 */	
				 parking=parkingService.add(park);
			
				/*
				 * @Invalidownerdetailexception: throwing the error for invalid data
				 *@since: 2019-05-23
				 */	
			
					
				 if(parking==null){
						return new ResponseEntity("Parking data has not been addedd!!!",HttpStatus.NOT_FOUND);
						
					}
			
				 
				 /*
					 * @ResponseEntity: its giving response to corresponding to the Parking object
					 *@since: 2019-05-23
					 */	
			return new ResponseEntity<Parking>(parking,HttpStatus.OK);
		}
		

		
		
		
		
		

		/*
		 * AddParkingslot method
		 * createParking: it is the uri though which we can reach to this method
		 * return: it returns the reponse of corresponding object
		 *@since: 2019-05-23
		 */		
		
		
		@RequestMapping(value="/addparkingslot",method=RequestMethod.POST)
		@CrossOrigin(origins="http://localhost:4200")
		public ResponseEntity<Parkingslot> addParkingslot(@RequestParam("startdate")String startDate,
				@RequestParam("enddate")String endDate,
				@RequestParam("starttime")String startTime,
				@RequestParam("endtime")String endTime,
				@RequestParam("id")Integer id) throws Invaliparkingidexception {
	
		

/*
 * Parkingservice method
 * SimpleDateFormat: is to check the date is in particular pattern or not
 *@since: 2019-05-23
 */	
			
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat dateFormatOne = new SimpleDateFormat("hh:mm");		   
				Date date1=null;
				Date date2=null;				
				Date date3=null;
				Date date4=null;
		
			
			/*
			 * Parkingservice method
			 * Parsing the data from string to date
			 *@since: 2019-05-23
			 */	
			try {
					date1 = dateFormat.parse(startDate);
				date2 = dateFormat.parse(endDate);				
					
							
			}catch(ParseException e) {	
					
						/*
						 * @exception: throwing the error for invalid date format
						 *@since: 2019-05-23
						 */	
					
				return new ResponseEntity("Please check and make sure that you are entering the correct Time format!!!"
						+ "Please enter time in dd/MM/yyyy format"
						+ "Example::- 27/05/2019!!",HttpStatus.NOT_FOUND);
			}
				
				
					
					/*
					 * Parkingservice method
					 * Parsing the data from string to time
					 *@since: 2019-05-23
					 */	
				
				try {
					date3= dateFormatOne.parse(startTime);
					date4= dateFormatOne.parse(endTime);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					
					/*
					 * @exception: throwing the error for invalid time format
					 *@since: 2019-05-23
					 */	
					return new ResponseEntity("Please check and make sure that you are entering the correct Time format!!!"
							+ "Please enter time in hh:mm format"
							+ "Example: for 10 hr and 30 minutes:- 10:30!!",HttpStatus.NOT_FOUND);
				}
					
									
				
					// TODO Auto-generated catch block
						
					
				
	

Parking parking=null;
Parkingslot parkingslot=null;
Parkingslot parkingslotOne=null;
			
			List<Parking> oer;
			
				oer = parkingService.searchbyid(id);
				
				for(Parking parki:oer)
				{
					parkingslot.setParking(parki);
				}
				
				
				/*
				 * Parkingslot method
				 * setting the date and time date to the parkingslot object
				 *@since: 2019-05-23
				 */	
				
				parkingslot.setStartDate(date1);
				parkingslot.setEndDate(date2);
				parkingslot.setStartTime(date3);
				parkingslot.setEndTime(date4);
				
				
				/*
				 * Parkingslot method
				 * create method: once the object is ready and we are passing it into the parameterlist of add method for adding Parkingslot
				 * Parking: we are saving the added data to Parkingslot
				 *@since: 2019-05-23
				 */	
				
				parkingslotOne=parkingslotService.createParkingslot(parkingslot);
				
			
			
				
				
				/*
				 * @exception: throwing the error for invalid parking
				 *@since: 2019-05-23
				 */	
				
			
			
			if(parkingslot==null){
				return new ResponseEntity("Parkingslot data has not been addedd!!!",HttpStatus.NOT_FOUND);
				
			}
			
			 
			 /*
				 * @ResponseEntity: its giving response to corresponding to the Parkingslot object
				 *@since: 2019-05-23
				 */	
			return new ResponseEntity<Parkingslot>(parkingslotOne,HttpStatus.OK);
		}
		
		
	
		
		

		/*
		 * bookParking method
		 * bookParking: it is the uri though which we can reach to this method
		 * return: it returns the reponse of corresponding object
		 *@since: 2019-05-23
		 */			
		
		@RequestMapping(value="/bookparking",method=RequestMethod.POST)
		public ResponseEntity<Parktransaction> bookParking(@RequestParam("startdate")String startDate,
				@RequestParam("enddate")String endDate,
				@RequestParam("starttime")String startTime,
				@RequestParam("endtime")String endTime,
				@ModelAttribute Parktransaction parktrans) throws Invaliparkingslotidexception, Invalidvehiclenumexception {
			
			
			
			/*
			 * Parkingslottransaction method
			 * SimpleDateFormat: is to check the date is in particular pattern or not
			 *@since: 2019-05-23
			 */			
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat dateFormatOne = new SimpleDateFormat("hh:mm");		   
				Date date1=null;

				Date date2=null;
				
				Date date3=null;

				Date date4=null;

				/*
				 * Parkingservice method
				 * Parsing the data from string to date
				 *@since: 2019-05-23
				 */
				
				
					try {
						date1 = dateFormat.parse(startDate);
						date2 = dateFormat.parse(endDate);	
					} catch (ParseException e) {
						// TODO Auto-generated catch block

						/*
						 * @exception: throwing the error for invalid date format
						 *@since: 2019-05-23
						 */	
						
						return new ResponseEntity("Please check and make sure that you are entering the correct Time format!!!"
								+ "Please enter time in dd/MM/yyyy format"
								+ "Example: - 27/05/2019!!",HttpStatus.NOT_FOUND);
					}
							
					
							
					
					
				
				
				
				
					/*
					 * Parkingservice method
					 * Parsing the data from string to time
					 *@since: 2019-05-23
					 */
				
				
					try {
						date3= dateFormatOne.parse(startTime);
						date4= dateFormatOne.parse(endTime);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						/*
						 * @exception: throwing the error for invalid time format
						 *@since: 2019-05-23
						 */	
						return new ResponseEntity("Please check and make sure that you are entering the correct Time format!!!"
								+ "Please enter time in hh:mm format"
								+ "Example: for 10 hr and 30 minutes:- 10:30!!",HttpStatus.NOT_FOUND);
					}
									
					
					// TODO Auto-generated catch block

						
				
				
	


Parkingslot parkingslot=null;
Vehicle vehicle=null;
Parktransaction parkingtransaction=null;
			
/*
 * Parkingtransaction method
 * book method: once the object is ready and we are passing it into the parameterlist of book method for adding Parkingtransaction
 * Parkingtrans: we are saving the added data to Parkingtransaction
 *@since: 2019-05-23
 */	

/*
 * Parkingtransaction method
 * setting the parkingslot to Prakingtransaction
 *@since: 2019-05-23
 */	
			List<Parkingslot> oer;
			
				oer = parkingslotService.searchbyid(parktrans.getParkingslot().getId());
				for(Parkingslot parki:oer)
				{
					parktrans.setParkingslot(parki);
				}
			
				/*
				 * @exception: throwing the exception for invalide parkingslotid
				 *@since: 2019-05-23
				 */	
			
			
			/*
			 * Parkingtransaction method
			 * setting the vehicle to Prakingtransaction
			 *@since: 2019-05-23
			 */	
			List<Vehicle> vehe;
			
				vehe = vehicleService.findBynumber(parktrans.getVehicle().getnumber());
				
				for(Vehicle vehee:vehe)
				{
					parktrans.setVehicle(vehee);
					
				}
			
				/*
				 * @exception: throwing the exception for invalide vehiclenuumber
				 *@since: 2019-05-23
				 */	
				

			
			
			/*
			 * Parkingtransaction method
			 * setting the vehicle object to Prakingtransaction
			 *@since: 2019-05-23
			 */	
		parktrans.setStartDate(date1);
				parktrans.setEndDate(date2);
				parktrans.setStartTime(date3);
				parktrans.setEndTime(date4);
				parkingtransaction=parktransService.bookParking(parktrans);
		if(parkingtransaction==null){
				return new ResponseEntity("Parkingstransaction data has not been addedd!!!",HttpStatus.NOT_FOUND);
				
			}
			
			 
			 /*
				 * @ResponseEntity: its giving response to corresponding to the ParkingTransaction object
				 *@since: 2019-05-23
				 */	
			return new ResponseEntity<Parktransaction>(parkingtransaction,HttpStatus.OK);
		}
		
		
		 @ExceptionHandler(Invalidownerdetailexception.class)
			public ResponseEntity handleInvalidownerDetailException(Invalidownerdetailexception ex) {

				

				return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);

			} 	
		 
		 @ExceptionHandler(Invalidowneridexception.class)
			public ResponseEntity handleInvalidownerIdException(Invalidowneridexception ex) {

				
				return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);

			} 	
		 
		 @ExceptionHandler(Invalidvehiclenumexception.class)
			public ResponseEntity handleInvalidvehicleException(Invalidvehiclenumexception ex) {

				
				return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);

			} 	
		 
		 @ExceptionHandler(Invaliparkingidexception.class)
			public ResponseEntity handleInvalidparkingException(Invaliparkingidexception ex) {

				
				return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);

			} 	
		 
		 @ExceptionHandler(Invaliparkingslotidexception.class)
			public ResponseEntity handleInvalidparkingslotException(Invaliparkingslotidexception ex) {

				
				return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);

			} 
		 
		 
		 @ExceptionHandler(Invaliddate.class)
			public ResponseEntity handleInvaliDateException(Invaliddate ex) {

				
				return new ResponseEntity("Please check and make sure that you are entering the correct Time format!!!"
						+ "Please enter time in dd/MM/yyyy format"
						+ "Example: for 10 hr and 30 minutes:- 27/05/2019!!",HttpStatus.NOT_FOUND);

			} 
		
		 @ExceptionHandler(Invalidtime.class)
			public ResponseEntity handleInvalidTimeException(Invalidtime ex) {

				
			return new ResponseEntity("Please check and make sure that you are entering the correct Time format!!!"
						+ "Please enter time in hh:mm format"
						+ "Example: for 10 hr and 30 minutes:- 10:30!!",HttpStatus.NOT_FOUND);

			} 
	}
	
	
	
	

