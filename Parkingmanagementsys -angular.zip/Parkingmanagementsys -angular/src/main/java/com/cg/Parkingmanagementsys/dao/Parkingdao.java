package com.cg.Parkingmanagementsys.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Parking;
import com.cg.Parkingmanagementsys.dto.Parkingslot;
/*
 * Parkingdao interface Repository
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
public interface Parkingdao  extends JpaRepository<Parking, Integer>{

/*
 * findByid: for finding the Parking
 * return: Parking list corresponding to the id
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
	
	public List<Parking> findByid(int id);
}
