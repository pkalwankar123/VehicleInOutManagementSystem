package com.cg.Parkingmanagementsys.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Parking;
import com.cg.Parkingmanagementsys.dto.Parkingslot;


/*
 * Parkingslotdao interface Repository
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
public interface Parkingslotdao extends JpaRepository<Parkingslot, Integer>{
	
	
	/*
	 * findByid: for finding the Parkingslot
	 * return: Parkingslot list corresponding to the id
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	public List<Parkingslot> findByid(int id);
}
