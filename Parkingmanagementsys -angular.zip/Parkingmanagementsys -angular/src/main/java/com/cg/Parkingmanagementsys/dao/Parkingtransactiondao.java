package com.cg.Parkingmanagementsys.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Parkingmanagementsys.dto.Parkingslot;
import com.cg.Parkingmanagementsys.dto.Parktransaction;
/*
 * Parkingtransactiondao interface Repository
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
public interface Parkingtransactiondao extends JpaRepository<Parktransaction, Integer>{

}
