package com.cg.Parkingmanagementsys.dto;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Future;

import org.springframework.format.annotation.DateTimeFormat;
//Entity class created
/*
*Parkingslot DTO class implemented by
*@author: Pradip kalwankar 
*@version: 1.0
*@since: 2019-05-14
*/



/*
*@Entity: creating the bean
*@Table: giving the table name
*@since: 2019-05-14
*/

@Entity
@Table(name="Parkingslot")
public class Parkingslot {
	/*
	 *@Attributes: following are the list of attributes
	 *@Id: unique name primary key for the entity
	 *@column: giving the column
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="parkingslot_id")
	private int id;
	
	@OneToOne(cascade=CascadeType.MERGE)
    @JoinColumn(name="parking_id")
	private Parking parking;
	
	//@Temporal(TemporalType.DATE)
	@Column(name="startdate")
	//@DateTimeFormat(pattern="dd/MM/yyyy")
	private Date startDate;
	//@Temporal(TemporalType.DATE)
	@Column(name="enddate")
	//@DateTimeFormat(pattern="dd/MM/yyyy")
	private Date endDate;
	//@Temporal(TemporalType.TIME)
	@Column(name="starttime")
	//@DateTimeFormat(pattern="HH:mm")
	private Date startTime;
	//@Temporal(TemporalType.TIME)
	@Column(name="endtime")
	//@DateTimeFormat(pattern="HH:mm")
	private Date endTime;

	/*
	 *@constructors: default and parameterized constructors
	 *@since: 2019-05-14
	 */
	public Parkingslot(){}
	public Parkingslot(int id, Parking parking, Date startDate, Date endDate,Date startTime, Date endTime) {
		super();
		this.id = id;
		this.parking = parking;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	/*
	 *@getter and setters: getters and setters
	 *@since: 2019-05-14
	 */

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Parking getParking() {
		return parking;
	}
	public void setParking(Parking parking) {
		this.parking = parking;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	/*
	 *@Tostring 
	 *@since: 2019-05-14
	 */
	@Override
	public String toString() {
		return "Parkingslot [id=" + id + ", parking=" + parking + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
		
	
	
	
}
