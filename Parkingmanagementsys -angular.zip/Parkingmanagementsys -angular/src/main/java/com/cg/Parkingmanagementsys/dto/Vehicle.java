package com.cg.Parkingmanagementsys.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



//Entity class created
/*
*Vehicle DTO class implemented by
*@author: Pradip kalwankar 
*@version: 1.0
*@since: 2019-05-14
*/



/*
*@Entity: creating the bean
*@Table: giving the table name
*@since: 2019-05-14
*/

@Entity
@Table(name="vehicle")
@JsonIgnoreProperties(value="valid")
public class Vehicle {
	/*
	 *@Attributes: following are the list of attributes
	 *@Id: unique name primary key for the entity
	 *@column: giving the column
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="vehicle_id")
	private int id;
	@Column(name="vehicle_number")
	private String number;
	@Column(name="vehicle_description")
	private String description;
	
	@ManyToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="owner_id")
	private Owner owner;
	
	
	

	/*
	 *@constructors: default and parameterized constructors
	 *@since: 2019-05-14
	 */
	public  Vehicle() {}

	public Vehicle(int id, String number, String description, Owner owner) {
		super();
		this.id = id;
		this.number = number;
		this.description = description;
		this.owner = owner;
	}

	/*
	 *@getter and setters: getters and setters
	 *@since: 2019-05-14
	 */

	public int getid() {
		return id;
	}


	public void setid(int id) {
		this.id = id;
	}


	public String getnumber() {
		return number;
	}


	public void setnumber(String number) {
		this.number = number;
	}


	public String getdescription() {
		return description;
	}


	public void setdescription(String description) {
		this.description = description;
	}

	
	public Owner getOwner() {
		return owner;
	}

	
	public void setOwner(Owner owner) {
		this.owner = owner;
	}
	/*
	 *@Tostring 
	 *@since: 2019-05-14
	 */
	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", number=" + number + ", description=" + description + ", owner=" + owner + "]";
	}

	

	

}