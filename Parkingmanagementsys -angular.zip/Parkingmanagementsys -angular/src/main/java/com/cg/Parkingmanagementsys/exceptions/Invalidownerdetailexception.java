package com.cg.Parkingmanagementsys.exceptions;

public class Invalidownerdetailexception extends Exception {
public Invalidownerdetailexception() {}
	
	public Invalidownerdetailexception(String msg) {
		super(msg);
	}
}
