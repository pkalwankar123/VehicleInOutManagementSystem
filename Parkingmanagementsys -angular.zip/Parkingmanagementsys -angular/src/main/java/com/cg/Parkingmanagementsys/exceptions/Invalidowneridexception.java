package com.cg.Parkingmanagementsys.exceptions;

public class Invalidowneridexception extends Exception {
	public Invalidowneridexception() {}
	
	public Invalidowneridexception(String msg) {
		super(msg);
	}
	
	
}
