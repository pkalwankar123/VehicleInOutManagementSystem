package com.cg.Parkingmanagementsys.exceptions;

public class Invaliparkingslotidexception extends Exception {
public Invaliparkingslotidexception() {}
	
	public Invaliparkingslotidexception(String msg) {
		super(msg);
	}
	
}
