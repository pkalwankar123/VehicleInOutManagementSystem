package com.cg.Parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.exceptions.Invalidownerdetailexception;
import com.cg.Parkingmanagementsys.exceptions.Invalidowneridexception;



/*
 * Ownerservice interface Service
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
public interface Ownerservice {
	
	
	

public Owner add(Owner owe);

public List<Owner> searchbyid(int id) throws Invalidowneridexception;

public List<Owner> Searchbyid(int id) throws Invalidownerdetailexception;
}
 