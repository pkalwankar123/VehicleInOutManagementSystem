package com.cg.Parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.cg.Parkingmanagementsys.dto.Owner;
import com.cg.Parkingmanagementsys.dto.Parkingslot;
import com.cg.Parkingmanagementsys.exceptions.Invaliparkingslotidexception;


/*
 * Parkingslotservice interface Service
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
public interface Parkingslotservice {
	public Parkingslot createParkingslot(Parkingslot parkingslot);
	public List<Parkingslot> searchbyid(int id) throws Invaliparkingslotidexception;
	

}