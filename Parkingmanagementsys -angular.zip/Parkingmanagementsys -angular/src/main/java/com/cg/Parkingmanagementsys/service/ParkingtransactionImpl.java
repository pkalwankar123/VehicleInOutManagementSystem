package com.cg.Parkingmanagementsys.service;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Parkingmanagementsys.dao.Parkingtransactiondao;
import com.cg.Parkingmanagementsys.dto.Parkingslot;
import com.cg.Parkingmanagementsys.dto.Parktransaction;


/*
 * ParkingslotserviceImp Service class implemented
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
@Service
@Transactional
public class ParkingtransactionImpl implements Parkingtransactionservice {
	static final Logger logger = Logger.getLogger(ParkingtransactionImpl.class); 	
	/*
	 * Autowired: for injecting the dao methods 
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	@Autowired
	Parkingtransactiondao praktransaDao;
	
	
	
	/*
	 * bookparking: for booking the transaction and passing the parameters 
	 *@author: Pradip kalwankar 
	 *@since: 2019-05-23
	 */
	@Override
	public Parktransaction bookParking(Parktransaction parktrans) {
		PropertyConfigurator.configure("D:\\Pradip spring\\Parkingmanagementsys\\src\\main\\java\\resources\\log4j.properties"); 
		logger.info("Parkingslot booked successful");
		/*
		 * @return: return the data from the dao
		 *@author: Pradip kalwankar 
		 *@since: 2019-05-23
		 */
		return praktransaDao.save(parktrans);
	}

}
