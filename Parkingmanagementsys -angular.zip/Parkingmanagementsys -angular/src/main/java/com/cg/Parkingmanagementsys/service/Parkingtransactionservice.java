package com.cg.Parkingmanagementsys.service;

import com.cg.Parkingmanagementsys.dto.Parkingslot;
import com.cg.Parkingmanagementsys.dto.Parktransaction;
/*
 * Parkingtransactionservice interface Service
 *@author: Pradip kalwankar 
 *@since: 2019-05-23
 */
public interface Parkingtransactionservice {
	public Parktransaction bookParking(Parktransaction parktrans);
}
