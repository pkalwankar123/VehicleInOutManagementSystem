import {Address} from './app.address'


export class Owner{
    id:number;
    name:string;
    mobNumber:number;
    address:Address;
}