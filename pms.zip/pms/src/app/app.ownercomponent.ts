
import { Component,OnInit} from "@angular/core";
import { ParkingService } from "./app.parkingservice";
import { Owner } from "./app.owner";
import {FormGroup,FormControl, Validators} from "@angular/forms";

@Component({
selector:'owner-app',
templateUrl:'app.owner.html'

})
export class OwnerComponent{



    id:number;
    name:string;
    mobNumber:number;
    houseNumber:string;
    street:string;
    city:string;
    pincode:number
    phoneNumber = "^(\+\d{1,3}[- ]?)?\d{10}$";
    ownerForm = new FormGroup({
        ownerid:new FormControl(''),
        ownerName:new FormControl('',Validators.required),
        ownerCantact:new FormControl(''),
        ownerHousnumber:new FormControl(''),
        ownerStreet:new FormControl(''),
        ownerCity:new FormControl(''),
       
        ownerPincode:new FormControl('')
});
   
    constructor(private oweservice:ParkingService){}

    owe:any={
       
    };

    

    addOwner(){
       this.oweservice.addAllOwner(this.ownerForm.value).subscribe(
           response => console.log('Success', response),
           error => console.error('Error', error)
       );
    console.log(this.ownerForm.value);
    }
}


