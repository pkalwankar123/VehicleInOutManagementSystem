
import { Component,OnInit} from "@angular/core";
import { ParkingService } from "./app.parkingservice";
//import { Parking } from "./app.parking";
import {FormGroup,FormControl, Validators} from "@angular/forms";

@Component({
selector:'parking-app',
templateUrl:'app.parking.html'

})
export class ParkingComponent{



    parkingForm = new FormGroup({
        ownerid:new FormControl(''),
        parkingid:new FormControl(''),
        parkingLocation:new FormControl('')
       
});
   
    constructor(private parkingservice:ParkingService){}

    owe:any={
       
    };

    

    addParking(){
       this.parkingservice.addAllParking(this.parkingForm.value).subscribe(
           response => console.log('Success', response),
           error => console.error('Error', error)
       );
    console.log(this.parkingForm.value);
    }
}


