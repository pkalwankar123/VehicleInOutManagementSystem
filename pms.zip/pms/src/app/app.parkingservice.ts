import{Injectable} from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from "rxjs"
import { Owner } from './app.owner';
import { Vehicle } from './app.vehicle';
@Injectable({
    providedIn:'root'
})
export class ParkingService{
   
    constructor(private http:HttpClient){}
   
    
    addAllOwner(userdata:any){
        let input=new FormData();
        input.append("id",userdata.ownerid);
        input.append("name",userdata.ownerName);
        input.append("mobNumber",userdata.ownerCantact);
        input.append("address.houseNumber",userdata.ownerHousnumber);
        input.append("address.street",userdata.ownerStreet);
        input.append("address.city",userdata.ownerCity);
        input.append("address.pincode",userdata.ownerPincode);
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/addowner",input);
    }
    
    addAllVehicle(vehicle:any){
        let input=new FormData();
        input.append("owner.id",vehicle.ownerid);
        input.append("number",vehicle.vehicleNumber);
        input.append("description",vehicle.vehicleDescription);
        
       
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/addvehicle",input)
    }
    searchAllVehicle(vehicles:any)
    {
        let input=new FormData();
        input.append("number",vehicles.number);
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/searchvehicle",input);
 
    }

    addAllParking(parking:any){
        let input=new FormData();
        input.append("owner.id",parking.ownerid);
        input.append("id",parking.parkingid);
        input.append("location",parking.parkingLocation);
        
       
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/addparking",input)
    }

    addAllParkingslot(userdata:any){
        let input=new FormData();
        input.append("parking.id",userdata.parkingid);
        input.append("startDate",userdata.startDate);
        input.append("endDate",userdata.endDate);
        input.append("startTime",userdata.starttime);
        input.append("endTime",userdata.endtime);
       
        return this.http.post<any>("http://localhost:9091/parkingmgtsys/addparkingslot",input);
    }

    }