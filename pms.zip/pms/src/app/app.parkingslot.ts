import { Component,OnInit} from "@angular/core";
import { ParkingService } from "./app.parkingservice";
//import { Owner } from "./app.owner";
import {FormGroup,FormControl, Validators} from "@angular/forms";

@Component({
selector:'parkingslot-app',
templateUrl:'app.parkingslot.html'

})
export class ParkingslotComponent{



    phoneNumber = "^(\+\d{1,3}[- ]?)?\d{10}$";
    parkingslotForm = new FormGroup({
        parkingid:new FormControl(''),
        startDate:new FormControl(''),
        endDate:new FormControl(''),
        starttime:new FormControl(''),
        endtime:new FormControl(''),
       
});
   
    constructor(private oweservice:ParkingService){}

    owe:any={
       
    };

    

    addParkingslot(){
       this.oweservice.addAllParkingslot(this.parkingslotForm.value).subscribe(
           response => console.log('Success', response)
          
       );
    console.log(this.parkingslotForm.value);
    }
}