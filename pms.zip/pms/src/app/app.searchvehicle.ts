import {Component, OnInit} from '@angular/core';
import { Vehicle } from './app.vehicle';
import { ParkingService } from './app.parkingservice';
@Component(
    {
        selector:'search-vehicle',
        templateUrl:'app.search.html'
    }
)
export class searchvehicle implements OnInit{
    vehicles:Vehicle[];
    model:any={};
    constructor(private parkingservice:ParkingService){}
    ngOnInit(){}
    searchVehicle()
    {
       this.parkingservice.searchAllVehicle(this.model).subscribe((data:Vehicle[])=>this.vehicles=data);
     
    }

}